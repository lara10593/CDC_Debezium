package com.example.BalanceOperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BalanceOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
