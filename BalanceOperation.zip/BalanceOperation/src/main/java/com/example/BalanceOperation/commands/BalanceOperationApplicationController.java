package com.example.BalanceOperation.commands;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.BalanceOperation.DataPersistence.AccountInfo;

@RestController
@RequestMapping("/BalanceOperation")
public class BalanceOperationApplicationController {

@Autowired
public com.example.BalanceOperation.DomainLogic.AccountInfoRepository AccountInfoRepository ;
	
	
@GetMapping("/getbalance/{accountid}")	
public AccountInfo getBankBalance(@PathVariable Integer accountid)
{
	AccountInfo AccountInforesult = new AccountInfo();
System.out.println(accountid);
	Optional<AccountInfo> AccountInfoOptional =AccountInfoRepository.findById(accountid);
	if(AccountInfoOptional.isPresent())
	{
		AccountInforesult = AccountInfoOptional.get();
	System.out.println(AccountInforesult);
		
	}
	
	return AccountInforesult;
}
	
	
}
