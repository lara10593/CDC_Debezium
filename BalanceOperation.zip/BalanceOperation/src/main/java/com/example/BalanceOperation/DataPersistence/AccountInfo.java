package com.example.BalanceOperation.DataPersistence;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "accounts")
public class AccountInfo {
	
	@Override
	public String toString() {
		return "AccountInfo [Username=" + Username + ", accountNumber=" + accountNumber + ", IFSCcode=" + IFSCcode
				+ ", balance=" + balance + "]";
	}
	public AccountInfo() {
		super();
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public Integer getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getIFSCcode() {
		return IFSCcode;
	}
	public void setIFSCcode(String iFSCcode) {
		IFSCcode = iFSCcode;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Column(nullable = false)
	private String Username;
	@Column(nullable = false)
	@Id
	private Integer accountNumber;
	@Column(nullable = false)
	private String IFSCcode;
	@Column(nullable = false)
	private double balance;
	
	public AccountInfo(String username, Integer accountNumber, String iFSCcode, double balance) {
		super();
		Username = username;
		this.accountNumber = accountNumber;
		IFSCcode = iFSCcode;
		this.balance = balance;
	}
	
	

}
