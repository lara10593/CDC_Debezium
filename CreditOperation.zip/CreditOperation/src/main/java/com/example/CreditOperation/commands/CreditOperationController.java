package com.example.CreditOperation.commands;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.CreditOperation.DomainLogic.AccountInfo;
import com.example.CreditOperation.DataPersistence.AccountInfoRepository;

@RestController
@RequestMapping("CreditOperation")
public class CreditOperationController {

	@Autowired
	public AccountInfoRepository accInfoRepo;
	
@PostMapping("/{Operation}/{accountid}/{amount}")
public String creditOrDebit(@PathVariable String Operation, @PathVariable Integer accountid,@PathVariable double amount)
{
	AccountInfo AccountInforesult = new AccountInfo();
		
	Optional<AccountInfo> AccountInfoOptional =accInfoRepo.findByaccountNumber(accountid);
	if(AccountInfoOptional.isPresent())
	{
		AccountInforesult = AccountInfoOptional.get();
		double availableBalance = AccountInforesult.getBalance();
		System.out.println(availableBalance);
		double newBalance = 0;
		if(Operation.equalsIgnoreCase("credit"))
		{
			newBalance = availableBalance + amount;
		}
		else if(Operation.equalsIgnoreCase("debit"))
		{
			newBalance = availableBalance - amount;
		}
		System.out.println(newBalance);
		AccountInforesult.setBalance(newBalance);
		
		accInfoRepo.save(AccountInforesult);
		
	System.out.println(AccountInforesult);
		
	}
	

	return "An amount of"+amount+"has been successfully credited in the user account : "+accountid;
}
	



}
