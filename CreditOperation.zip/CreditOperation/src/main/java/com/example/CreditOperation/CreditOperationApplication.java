package com.example.CreditOperation;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.CreditOperation.DataPersistence.AccountInfoRepository;
import com.example.CreditOperation.DomainLogic.*;

@SpringBootApplication
public class CreditOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditOperationApplication.class, args);
	}
	
	
	
	 @Bean
	    public CommandLineRunner AccountInfoRepositoryDemo(AccountInfoRepository AccountInfoRepository) {
	        return (args) -> {

	            // create notes
	        	AccountInfoRepository.save
	        	(new AccountInfo("lara",10001,"ICIC0001040",5417.00));
	        	
	        	AccountInfoRepository.save
	        	(new AccountInfo("lakshmi",10002,"HDFC0001852",18746.00));
	        	
	        	
	        	AccountInfoRepository.save
	        	(new AccountInfo("Narasimhan",10003,"ICIC0001040",876542.00));
	        	
	           
	                };
	    }
	 
	 

}
