package com.example.CreditOperation.DataPersistence;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.CreditOperation.DomainLogic.AccountInfo;

public interface AccountInfoRepository  extends JpaRepository<AccountInfo, Integer>{

	public Optional<AccountInfo> findByaccountNumber(Integer a);
	
	
	

}

